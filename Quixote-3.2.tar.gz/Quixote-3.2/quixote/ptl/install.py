import quixote.ptl.ptl_import
quixote.ptl.ptl_import.install()
